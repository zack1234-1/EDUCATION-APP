import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseConfig {
  static FirebaseOptions get platformOptions{
    return const FirebaseOptions(
        appId: "1:584383106829:android:556120aa9b922aebb5ea44",
        apiKey: "AIzaSyChWEUt_xaNUd4y5_gQV0mAhb_sJvmb5zU",
        projectId: "csexplorer-433ae",
        messagingSenderId: "673162291780");
  }
}
